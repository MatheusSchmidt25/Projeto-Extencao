package com.example.trabalhomobile.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.trabalhomobile.Global;
import com.example.trabalhomobile.R;
import com.example.trabalhomobile.controller.PedidoController;
import com.example.trabalhomobile.dao.PedidoDao;
import com.example.trabalhomobile.dao.ProdutosDao;
import com.example.trabalhomobile.dao.VendedorDao;
import com.example.trabalhomobile.model.Pedido;
import com.example.trabalhomobile.model.Produtos;
import com.example.trabalhomobile.model.Vendedor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PedidosActivity extends AppCompatActivity {


    private EditText etCliente;
    private Spinner spProduto;
    private Spinner spPagamento;
    private Button btVoltar;
    private Button btFinalizar;
    private String formaPagamentoSelecionada;
    private String produtoSelecionado;
    private String produto = "";
    private Context context;
    String nomeVendedor = Global.nomeVendedor;
    String vista = "À vista";
    String parcelado = "Parcelado";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedidos);

        spProduto = findViewById(R.id.spProduto);
        spPagamento = findViewById(R.id.spPagamento);
        etCliente = findViewById(R.id.etCliente);
        btVoltar = findViewById(R.id.btVoltar);
        btFinalizar = findViewById(R.id.btFinalizar);

        String teste = Global.nomeVendedor;

        context = this;
        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltar();
            }
        });
        btFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finalizar();
            }
        });
        spPagamento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                formaPagamentoSelecionada = (String) spPagamento.getSelectedItem();
                Toast.makeText(PedidosActivity.this, "Forma de pagamento selecionada: " + formaPagamentoSelecionada, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spProduto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                produtoSelecionado = (String) spProduto.getSelectedItem();
                if (produtoSelecionado == "Escolha um Prduto:")
                    produtoSelecionado = "";
                produto += produtoSelecionado+", \n";
                 }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        configurarSpinnerPagamento();
        carregarProdutos();





        // Use o nome do vendedor conforme necessário
        Toast.makeText(this, "Bem-vindo, " + nomeVendedor + "!", Toast.LENGTH_SHORT).show();
    }
    private void finalizar() {

        String cliente = etCliente.getText().toString();

        if(cliente.equals("") || cliente.isEmpty() || produtoSelecionado.equals("") || produtoSelecionado.isEmpty() || formaPagamentoSelecionada.equals("") || formaPagamentoSelecionada.isEmpty()){
            Toast.makeText(PedidosActivity.this, "Preencha todos os campos ! ", Toast.LENGTH_SHORT).show();
        }else{

        ArrayList<Produtos> listaProdutos = ProdutosDao.getInstancia(this).getAll();
        for (Produtos produtos : listaProdutos) {
            if (produtos.getModelo().equals(produtoSelecionado)) {
                Pedido pedido = new Pedido();
                pedido.setVendedor(nomeVendedor);
                pedido.setCliente(cliente);
                pedido.setMarca(produtos.getMarca());
                pedido.setModelo(produtos.getModelo());
                pedido.setValor(produtos.getValor());
                pedido.setFormaPagamento(formaPagamentoSelecionada);
                if (formaPagamentoSelecionada.equals(vista)){
                    double total = produtos.getValor() * 0.95;
                    pedido.setTotal(total);
                } else if (formaPagamentoSelecionada.equals(parcelado)) {
                    double total = produtos.getValor() * 1.05;
                    pedido.setTotal(total);
                }
                PedidoDao.getInstance(this).insert(pedido);

                Toast.makeText(PedidosActivity.this, "Pedido Salvo com Sucesso! ", Toast.LENGTH_SHORT).show();
                finish();
            }}
        }
    }
    private void voltar() {
        finish();
    }

    private void configurarSpinnerPagamento() {
        List<String> opcoesPagamento = Arrays.asList(vista, parcelado);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcoesPagamento);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spPagamento.setAdapter(adapter);
    }
    private void carregarProdutos() {
        ProdutosDao produtosDao = ProdutosDao.getInstancia(this);
        ArrayList<String> modelosProdutos = produtosDao.getModelosProdutos();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, modelosProdutos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spProduto.setAdapter(adapter);
    }
}