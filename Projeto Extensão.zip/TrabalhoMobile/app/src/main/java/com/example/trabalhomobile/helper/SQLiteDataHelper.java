package com.example.trabalhomobile.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import androidx.annotation.Nullable;

public class SQLiteDataHelper extends SQLiteOpenHelper {

    public SQLiteDataHelper(@Nullable Context context,
                            @Nullable String name,
                            @Nullable SQLiteDatabase.CursorFactory factory,
                            int version) {
        super(context, name, factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE VENDEDOR (ID INTEGER, NOME VARCHAR(50)," +
                "CPF VARCHAR(50), LOGIN VARCHAR(50), SENHA VARCHAR(50))");

        sqLiteDatabase.execSQL("CREATE TABLE PEDIDO (VENDEDOR VARCHAR(50),CLIENTE VARCHAR(50),MARCA VARCHAR(50) ,MODELO VARCHAR(50)," +
                "VALOR DOUBLE,TOTAL DOUBLE, FORMAPAGAMENTO VARCHAR(50))");

        sqLiteDatabase.execSQL("CREATE TABLE PRODUTOS (MARCA VARCHAR(50),MODELO VARCHAR(50), VALOR DOUBLE)");

        sqLiteDatabase.execSQL("INSERT INTO PRODUTOS (MARCA, MODELO, VALOR) VALUES\n" +
                "    ('Toyota', 'Corolla', 50000.00),\n" +
                "    ('Honda', 'Civic', 48000.00),\n" +
                "    ('Ford', 'Mustang', 65000.00),\n" +
                "    ('Chevrolet', 'Camaro', 70000.00),\n" +
                "    ('Volkswagen', 'Golf', 45000.00),\n" +
                "    ('Nissan', 'Altima', 52000.00),\n" +
                "    ('BMW', 'X5', 75000.00),\n" +
                "    ('Mercedes-Benz', 'C-Class', 60000.00),\n" +
                "    ('Audi', 'A4', 58000.00),\n" +
                "    ('Hyundai', 'Elantra', 42000.00),\n" +
                "    ('Kia', 'Optima', 46000.00);\n");

        }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

}
