package com.example.trabalhomobile.model;

public class Pedido {


   private String cliente;
   private String vendedor;
   private String marca;
   private String modelo;
   private double valor;
   private Double total;
   private String formaPagamento;

   public Pedido() {
   }

   public String getCliente() {
      return cliente;
   }

   public void setCliente(String cliente) {
      this.cliente = cliente;
   }

   public String getVendedor() {
      return vendedor;
   }

   public void setVendedor(String vendedor) {
      this.vendedor = vendedor;
   }

   public String getMarca() {
      return marca;
   }

   public void setMarca(String marca) {
      this.marca = marca;
   }

   public String getModelo() {
      return modelo;
   }

   public void setModelo(String modelo) {
      this.modelo = modelo;
   }

   public double getValor() {
      return valor;
   }

   public void setValor(double valor) {
      this.valor = valor;
   }

   public Double getTotal() {
      return total;
   }

   public void setTotal(Double total) {
      this.total = total;
   }

   public String getFormaPagamento() {
      return formaPagamento;
   }

   public void setFormaPagamento(String formaPagamento) {
      this.formaPagamento = formaPagamento;
   }
}
