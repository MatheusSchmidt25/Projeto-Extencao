package com.example.trabalhomobile.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.trabalhomobile.helper.SQLiteDataHelper;
import com.example.trabalhomobile.model.Vendedor;

import java.util.ArrayList;

public class VendedorDao implements IGenericDao<Vendedor>{

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase baseDados;
    private String[]colunas = {"ID", "NOME", "CPF", "LOGIN", "SENHA"};
    private String tabela = "VENDEDOR";
    private Context context;

    private static VendedorDao instancia;

    public static VendedorDao getInstancia(Context context){
        if (instancia == null){
            return instancia = new VendedorDao(context);
        }else{
            return  instancia;
        }
    }

    private VendedorDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "LOJA_BD", null, 1);
        baseDados = openHelper.getWritableDatabase();

    }

    @Override
    public long insert(Vendedor obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getId());
            valores.put(colunas[1], obj.getNome());
            valores.put(colunas[2], obj.getCpf());
            valores.put(colunas[3], obj.getLogin());
            valores.put(colunas[4], obj.getSenha());

            return baseDados.insert(tabela, null, valores);
        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: VendedorDao.insert() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Vendedor obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getNome());

            String[] identificador = {String.valueOf(obj.getId())};

            return baseDados.update(tabela, valores,colunas[0]+"= ?", identificador);
        }catch(SQLException ex){
            Log.e("VENDAS", "ERRO: VendedorDao.update() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Vendedor obj) {
        try{
            String[]identificador = {String.valueOf(obj.getId())};

            return baseDados.delete(tabela, colunas[0]+ "= ?", identificador);
        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: VendedorDao.delete() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public ArrayList<Vendedor> getAll() {
        ArrayList<Vendedor> lista = new ArrayList<>();
        try{
            Cursor cursor = baseDados.query(tabela, colunas, null,null,
                    null,null, colunas[0]+" desc");

            if(cursor.moveToFirst()){
                do{
                    Vendedor vendedor = new Vendedor();
                    vendedor.setId(cursor.getInt(0));
                    vendedor.setNome(cursor.getString(1));
                    vendedor.setCpf(cursor.getString(2));
                    vendedor.setLogin(cursor.getString(3));
                    vendedor.setSenha(cursor.getString(4));

                    lista.add(vendedor);

                }while (cursor.moveToNext());
            }

        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: VendedorDao.etAll() "+ex.getMessage());
        }
        return lista;
    }

    @Override
    public Vendedor getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = baseDados.query(tabela, colunas,
                    colunas[0]+"= ?", identificador,
                    null, null, null);

            if (cursor.moveToFirst()){
                Vendedor vendedor = new Vendedor();
                vendedor.setId(cursor.getInt(0));
                vendedor.setNome(cursor.getString(1));
                vendedor.setCpf(cursor.getString(2));
                vendedor.setLogin(cursor.getString(3));
                vendedor.setSenha(cursor.getString(4));

                return vendedor;
            }
        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: VendedorDao.getById() "+ex.getMessage());
        }
        return null;
    }
}