package com.example.trabalhomobile.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.trabalhomobile.helper.SQLiteDataHelper;
import com.example.trabalhomobile.model.Pedido;

import java.util.ArrayList;

public class PedidoDao implements IGenericDao<Pedido> {

    public SQLiteOpenHelper openHelper;
    private SQLiteDatabase baseDados;

    private String[]colunas = {"VENDEDOR","CLIENTE","MARCA", "MODELO", "VALOR","TOTAL", "FORMAPAGAMENTO"};
    private String tabela = "PEDIDO";
    private Context context;

    private static  PedidoDao instancia;

    public static PedidoDao getInstance(Context context){
        if (instancia == null){
            return instancia = new PedidoDao(context);
        }else{
            return  instancia;
        }
    }

    private PedidoDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "LOJA_BD", null, 1);
        baseDados = openHelper.getWritableDatabase();

    }



    @Override
    public long insert(Pedido obj) {
        try {
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getVendedor());
            valores.put(colunas[1], obj.getCliente());
            valores.put(colunas[2], obj.getMarca());
            valores.put(colunas[3], obj.getModelo());
            valores.put(colunas[4], obj.getValor());
            valores.put(colunas[5], obj.getTotal());
            valores.put(colunas[6], obj.getFormaPagamento());

            return  baseDados.insert(tabela, null, valores);
        }catch (SQLException ex){
            Log.e("PRDUTO", "ERRO: ProdutoDao.insert() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Pedido obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getCliente());

            String[] identificador = {String.valueOf(obj.getCliente())};

            return baseDados.update(tabela, valores, colunas[0]+"= ?", identificador);
        }catch (SQLException ex) {
            Log.e("PRODUTO", "ERRO: ProdutoDao.update() " + ex.getMessage());
        }
            return 0;
    }

    @Override
    public long delete(Pedido obj) {
        try{
            String[]identificador = {String.valueOf(obj.getCliente())};

            return baseDados.delete(tabela, colunas[0]+ "= ?", identificador);
        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: VendedorDao.delete() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public ArrayList<Pedido> getAll() {
        ArrayList<Pedido> lista = new ArrayList<>();
        try{
            Cursor cursor = baseDados.query(tabela, colunas, null,null,
                    null,null, colunas[0]+" desc");

            if(cursor.moveToFirst()){
                do{
                    Pedido pedido = new Pedido();
                    pedido.setVendedor(cursor.getString(0));
                    pedido.setCliente(cursor.getString(1));
                    pedido.setMarca(cursor.getString(2));
                    pedido.setModelo(cursor.getString(3));
                    pedido.setValor(cursor.getDouble(4));
                    pedido.setTotal(cursor.getDouble(5));
                    pedido.setFormaPagamento(cursor.getString(6));

                    lista.add(pedido);

                }while (cursor.moveToNext());
            }

        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: PedidorDao.etAll() "+ex.getMessage());
        }
        return lista;

    }

    @Override
    public Pedido getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = baseDados.query(tabela, colunas,
                    colunas[0]+"= ?", identificador,
                    null, null, null);

            if(cursor.moveToFirst()) {
                Pedido pedido = new Pedido();
                pedido.setVendedor(cursor.getString(0));
                pedido.setCliente(cursor.getString(1));
                pedido.setMarca(cursor.getString(2));
                pedido.setModelo(cursor.getString(3));
                pedido.setValor(cursor.getDouble(4));
                pedido.setTotal(cursor.getDouble(5));
                pedido.setFormaPagamento(cursor.getString(6));

                return pedido;
            }
        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: PedidoDao.getById() "+ex.getMessage());
        }
        return null;
    }

    public ArrayList<String> getNomesProdutos() {
        ArrayList<String> nomesProdutos = new ArrayList<>();
        try {
            Cursor cursor = baseDados.query(true, "PRODUTOS", new String[]{"NOME"}, null, null, null, null, null, null);

            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") String nomeProduto = cursor.getString(cursor.getColumnIndex("NOME"));
                    nomesProdutos.add(nomeProduto);
                } while (cursor.moveToNext());
            }

            cursor.close();
        } catch (SQLException ex) {
            Log.e("PEDIDO", "ERRO: PedidoDao.getNomesProdutos() " + ex.getMessage());
        }
        return nomesProdutos;
    }

    public double getValorProduto(String nomeProduto) {
        try {
            Cursor cursor = baseDados.query("PRODUTOS", new String[]{"VALOR"}, "MODELO = ?", new String[]{nomeProduto}, null, null, null);

            if (cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex("VALOR");
                return cursor.getDouble(columnIndex);
            }
            cursor.close();
        } catch (SQLException ex) {
            Log.e("PEDIDO", "ERRO: PedidoDao.getValorProduto() " + ex.getMessage());
        }
        return 0.0;
    }



    }







